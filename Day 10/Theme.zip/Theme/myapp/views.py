from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import ListView
from .models import student

# Create your views here.

def homepageview(request):
    return render(request,'home.html')


def aboutpageview(request):
    return render(request,'about.html')


def contactpageview(request):
    return render(request,'contact.html')

def signuppage(request):
    return render(request,'signup.html')

def loginpage(request):
    return render(request,'login.html')

def myform(request):
    return render(request,'myform.html')

def process(request):
    print(request.method)
    print(request.POST)
    a = int(request.POST['text1'])
    b = int(request.POST['text2'])
    c = a+b
    return render(request,'ans.html' , {'mysum' : c})
    

class studentlist(ListView):
    model = student
    template_name ='slist.html'